import axios from 'axios';

const api = axios.create({
    baseURL: 'http://127.0.0.1:8000/api', 
});

// এই অংশটি নিশ্চিত করে যে প্রতিবার API কল করার সময় টোকেন সাথে যাবে
api.interceptors.request.use((config) => {
    const token = localStorage.getItem('access_token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
}, (error) => {
    return Promise.reject(error);
});

export default api;