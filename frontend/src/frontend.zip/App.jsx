import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import PrivateRoute from './routes/PrivateRoute';
import CourseList from './pages/CourseList'; 
import Profile from './pages/Profile';

function App() {
  return (
    <Router>
      {/* Container to fix background and clicks */}
      <div style={{ 
        minHeight: '100vh', 
        width: '100vw', 
        backgroundColor: '#ffffff', 
        color: '#000000',
        position: 'relative',
        zIndex: 1
      }}>
        <nav style={{ 
          padding: '20px', 
          background: '#f8f9fa', 
          borderBottom: '1px solid #ddd', 
          display: 'flex', 
          justifyContent: 'center', 
          gap: '20px' 
        }}>
          <Link to="/" style={{ color: '#007bff', fontWeight: 'bold' }}>Home</Link>
          <Link to="/register" style={{ color: '#007bff', fontWeight: 'bold' }}>Register</Link>
          <Link to="/login" style={{ color: '#007bff', fontWeight: 'bold' }}>Login</Link>
          <Link to="/dashboard" style={{ color: '#007bff', fontWeight: 'bold' }}>Dashboard</Link>
          <Link to="/profile" style={{ color: '#007bff', fontWeight: 'bold' }}>Profile</Link>
        </nav>

        <div style={{ padding: '40px', textAlign: 'center' }}>
          <Routes>
            <Route path="/" element={<h1>Welcome to LMS</h1>} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/courses" element={<CourseList />} />  
            <Route path="/dashboard" element={
              <PrivateRoute>
                <Dashboard />
              </PrivateRoute>
            } />
            <Route path="/profile" element={
              <PrivateRoute>
                <Profile />
              </PrivateRoute>
            } />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;