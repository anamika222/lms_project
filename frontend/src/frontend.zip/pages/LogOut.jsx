import React, { useEffect, useState } from 'react';
import api from '../api/axios';

const Dashboard = () => {
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const token = localStorage.getItem('access_token');
        
        api.get('/users/admin-dashboard-summary/', {
            headers: { Authorization: `Bearer ${token}` }
        })
        .then(res => {
            console.log("Backend Data:", res.data);
            setStats(res.data);
            setLoading(false);
        })
        .catch(err => {
            console.error("Dashboard Fetch Error:", err);
            setError(err.response?.data?.detail || "Failed to fetch dashboard data");
            setLoading(false);
        });
    }, []);

    if (loading) return <div style={{ padding: '50px', textAlign: 'center' }}><h2>Loading Dashboard Summary...</h2></div>;

    if (error) return (
        <div style={{ padding: '20px', color: 'red', textAlign: 'center' }}>
            <h2>Error: {error}</h2>
            <p>Please log out and log in again.</p>
        </div>
    );

    return (
        <div style={{ padding: '30px', backgroundColor: '#f4f7f6', minHeight: '100vh' }}>
            <h2 style={{ marginBottom: '20px', color: '#333' }}>Admin Dashboard Summary</h2> 
            
            <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
                {/* User Summary Card [cite: 46, 68] */}
                <div style={cardStyle}>
                    <h3 style={{ color: '#555' }}>Total Users</h3>
                    <p style={numberStyle}>{stats?.total_users ?? 0}</p> 
                </div>

                {/* Course Summary Card [cite: 47, 68] */}
                <div style={cardStyle}>
                    <h3 style={{ color: '#555' }}>Total Courses</h3>
                    <p style={numberStyle}>{stats?.total_courses ?? 0}</p> 
                </div>

                {/* Enrollment Summary Card [cite: 48, 68] */}
                <div style={cardStyle}>
                    <h3 style={{ color: '#555' }}>Enrollments</h3>
                    <p style={numberStyle}>{stats?.total_enrollments ?? 0}</p> 
                </div>
            </div>

            {/* Role-wise Statistics [cite: 49, 69] */}
            {stats?.role_wise && (
                <div style={{ marginTop: '30px', padding: '20px', background: '#fff', borderRadius: '8px' }}>
                    <h3>Role-wise User Count</h3>
                    <ul>
                        <li>Admins: {stats.role_wise.admin}</li>
                        <li>Instructors: {stats.role_wise.instructor}</li>
                        <li>Students: {stats.role_wise.student}</li>
                    </ul>
                </div>
            )}
        </div>
    );
};



const cardStyle = { 
    background: '#fff', 
    padding: '25px', 
    borderRadius: '12px', 
    boxShadow: '0 4px 6px rgba(0,0,0,0.1)', 
    minWidth: '250px',
    textAlign: 'center'
};

const numberStyle = { fontSize: '32px', fontWeight: 'bold', color: '#007bff', margin: '10px 0' };

export default Dashboard;